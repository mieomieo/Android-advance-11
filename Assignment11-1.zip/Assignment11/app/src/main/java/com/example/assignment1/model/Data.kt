package com.example.assignment1.model

class Data(val id:Int, val url:String)